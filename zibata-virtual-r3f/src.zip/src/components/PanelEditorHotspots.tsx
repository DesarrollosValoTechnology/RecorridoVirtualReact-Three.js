import { useTourStore } from '../store/useTourStore';

export default function PanelEditorHotspots() {
    const { setAdminPanelActivo, crearNuevoHotspot } = useTourStore();

    return (
        <div style={{
            position: 'absolute', top: '20px', left: '100px', 
            backgroundColor: 'rgba(20, 20, 20, 0.85)', backdropFilter: 'blur(10px)',
            padding: '20px', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.1)',
            color: 'white', fontFamily: 'sans-serif', zIndex: 99999, width: '300px'
        }}>
            <button 
                onClick={() => setAdminPanelActivo(null)}
                style={{ position: 'absolute', top: '15px', right: '15px', background: 'transparent', border: 'none', color: '#888', cursor: 'pointer' }}
            >✖</button>

            <h3 style={{ marginTop: 0, borderBottom: '1px solid #333', paddingBottom: '10px' }}>🎯 Editor de Hotspots</h3>
            <p style={{ fontSize: '13px', color: '#ccc' }}>
                Arrastra las esferas magenta usando las flechas de colores para posicionarlas.
            </p>

            <button 
                onClick={crearNuevoHotspot}
                style={{
                    width: '100%', padding: '10px', marginTop: '10px',
                    backgroundColor: '#4a90e2', color: 'white', border: 'none', 
                    borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold'
                }}
            >
                + Crear Nuevo Hotspot
            </button>
        </div>
    );
}