import { useState, useEffect } from 'react';
import { useTourStore } from '../store/useTourStore';

export default function PanelEditarNodo() {
    const { nodos, nodoActual, actualizarNodoActual, setAdminPanelActivo } = useTourStore();
    const info = nodos[nodoActual];

    // 🚨 CORRECCIÓN: Añadimos lat y lng aquí para que TypeScript las reconozca
    const [datos, setDatos] = useState({
        titulo: '',
        mapa_x: 0,
        mapa_y: 0,
        norte_offset: 0,
        lat: 0,
        lng: 0
    });

    useEffect(() => {
        if (info) {
            setDatos({
                titulo: info.ui.titulo || '',
                mapa_x: info.mapaX || 0,
                mapa_y: info.mapaY || 0,
                norte_offset: info.norteOffset || 0,
                lat: info.lat || 0,
                lng: info.lng || 0
            });
        }
    }, [nodoActual, info]);

    const handleChange = (e: any) => {
        const { name, value } = e.target;
        // Convertimos a número si no es el título
        const valorFinal = name === 'titulo' ? value : Number(value);
        
        const nuevosDatos = { ...datos, [name]: valorFinal };
        setDatos(nuevosDatos);
        
        // Auto-guardado para coordenadas, norte y GPS
        if (name !== 'titulo') {
            actualizarNodoActual({ [name]: valorFinal });
        }
    };

    const labelStyle = { display: 'block', fontSize: '11px', color: '#888', marginBottom: '5px', marginTop: '10px' };
    const inputStyle = { width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #333', backgroundColor: '#111', color: 'white' };

    return (
        <div style={{
            position: 'absolute', top: '20px', right: '20px', width: '280px',
            backgroundColor: 'rgba(15, 15, 15, 0.9)', backdropFilter: 'blur(10px)',
            padding: '25px', borderRadius: '15px', border: '1px solid rgba(255,255,255,0.1)',
            color: 'white', zIndex: 100000, fontFamily: 'sans-serif'
        }}>
            <h3 style={{ marginTop: 0 }}>⚙️ Config. de Escena</h3>
            <p style={{ fontSize: '12px', color: '#666' }}>ID: <span style={{ color: '#aaa' }}>{nodoActual}</span></p>

            <label style={labelStyle}>TÍTULO DE LA ESCENA</label>
            <input 
                name="titulo" 
                value={datos.titulo} 
                style={inputStyle} 
                onChange={handleChange} 
                onBlur={() => actualizarNodoActual({ titulo: datos.titulo })} 
            />

            <div style={{ display: 'flex', gap: '10px' }}>
                <div style={{ flex: 1 }}>
                    <label style={labelStyle}>POS. X (%)</label>
                    <input type="number" name="mapa_x" value={datos.mapa_x} style={inputStyle} onChange={handleChange} />
                </div>
                <div style={{ flex: 1 }}>
                    <label style={labelStyle}>POS. Y (%)</label>
                    <input type="number" name="mapa_y" value={datos.mapa_y} style={inputStyle} onChange={handleChange} />
                </div>
            </div>

            <label style={labelStyle}>AJUSTE NORTE (GRADOS)</label>
            <input type="range" name="norte_offset" min="0" max="360" value={datos.norte_offset} style={{ width: '100%' }} onChange={handleChange} />
            <div style={{ textAlign: 'center', fontSize: '12px' }}>{datos.norte_offset}°</div>

            {/* SECCIÓN DE GPS REAL */}
            <div style={{ borderTop: '1px solid #333', marginTop: '15px', paddingTop: '5px' }}>
                <label style={{ ...labelStyle, color: '#4a90e2' }}>📍 UBICACIÓN GOOGLE MAPS</label>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>LATITUD</label>
                        <input 
                            type="number" 
                            name="lat" 
                            step="any"
                            value={datos.lat} 
                            style={inputStyle} 
                            onChange={handleChange} 
                        />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>LONGITUD</label>
                        <input 
                            type="number" 
                            name="lng" 
                            step="any"
                            value={datos.lng} 
                            style={inputStyle} 
                            onChange={handleChange} 
                        />
                    </div>
                </div>
            </div>

            <button 
                onClick={() => setAdminPanelActivo(null)}
                style={{ 
                    width: '100%', 
                    padding: '10px', 
                    marginTop: '20px', 
                    backgroundColor: '#333', 
                    color: 'white', 
                    border: 'none', 
                    borderRadius: '8px', 
                    cursor: 'pointer' 
                }}
            >
                Cerrar Editor
            </button>
        </div>
    );
}