import { useState } from 'react';
import { supabase } from '../supabase/client';
import { useTourStore } from '../store/useTourStore';

export default function AdminMode() {
    const { setAdminPanelActivo, cargarNodos } = useTourStore();
    const [cargando, setCargando] = useState(false);
    const [mensaje, setMensaje] = useState('');
    
    // 1. ESTADOS PARA LOS ARCHIVOS
    const [archivo360, setArchivo360] = useState<File | null>(null);
    const [archivoMini, setArchivoMini] = useState<File | null>(null);

    const [formData, setFormData] = useState({
        id: '',
        titulo: '',
        mapa_x: 50,
        mapa_y: 50,
        lat: '',
        lng: '',
        norte_offset: 0
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Manejadores de archivos individuales
    const handleFile360Change = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) setArchivo360(e.target.files[0]);
    };

    const handleMiniChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) setArchivoMini(e.target.files[0]);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!archivo360 || !archivoMini) {
            setMensaje('❌ Por favor selecciona ambas imágenes (360 y Miniatura)');
            return;
        }

        setCargando(true);
        setMensaje('Subiendo imágenes a Supabase...');

        try {
            // --- PASO 1: Subir Foto 360 ---
            const name360 = `${formData.id}-360-${Math.random().toString(36).substring(7)}.webp`;
            const { error: err360 } = await supabase.storage.from('fotos_tour').upload(name360, archivo360);
            if (err360) throw err360;
            const { data: url360 } = supabase.storage.from('fotos_tour').getPublicUrl(name360);

            // --- PASO 2: Subir Miniatura ---
            const nameMini = `${formData.id}-thumb-${Math.random().toString(36).substring(7)}.webp`;
            const { error: errMini } = await supabase.storage.from('fotos_tour').upload(nameMini, archivoMini);
            if (errMini) throw errMini;
            const { data: urlMini } = supabase.storage.from('fotos_tour').getPublicUrl(nameMini);

            setMensaje('Registrando en base de datos...');

            // --- PASO 3: Insertar en Tabla Nodos ---
            const { error: insertError } = await supabase
                .from('nodos')
                .insert([{
                    id: formData.id.toLowerCase().replace(/\s+/g, '_'),
                    titulo: formData.titulo,
                    foto_url: url360.publicUrl,
                    miniatura_url: urlMini.publicUrl, // 👈 El campo que nos faltaba
                    mapa_x: Number(formData.mapa_x),
                    mapa_y: Number(formData.mapa_y),
                    lat: formData.lat ? Number(formData.lat) : null,
                    lng: formData.lng ? Number(formData.lng) : null,
                    norte_offset: Number(formData.norte_offset)
                }]);

            if (insertError) throw insertError;

            setMensaje('✅ ¡Nodo y Miniatura creados con éxito!');
            await cargarNodos(); // Recargamos para que aparezca en el menú
            
        } catch (error: any) {
            console.error(error);
            setMensaje(`❌ Error: ${error.message}`);
        } finally {
            setCargando(false);
        }
    };

    const labelStyle = { display: 'block', marginBottom: '5px', fontSize: '11px', color: '#aaa', textTransform: 'uppercase' as const, letterSpacing: '1px' };
    const inputStyle = { width: '100%', padding: '10px', marginBottom: '15px', borderRadius: '8px', border: '1px solid #333', backgroundColor: 'rgba(0,0,0,0.5)', color: 'white', outline: 'none', fontSize: '14px' };

    return (
        <div style={{
            position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
            backgroundColor: 'rgba(20, 20, 20, 0.95)', backdropFilter: 'blur(15px)',
            padding: '30px', borderRadius: '20px', border: '1px solid rgba(255,255,255,0.1)',
            width: '420px', maxHeight: '90vh', overflowY: 'auto', zIndex: 99999, color: 'white', fontFamily: 'sans-serif'
        }}>
            <button onClick={() => setAdminPanelActivo(null)} style={{ position: 'absolute', top: '20px', right: '20px', background: 'none', border: 'none', color: '#666', fontSize: '20px', cursor: 'pointer' }}>✖</button>
            
            <h2 style={{ marginTop: 0, marginBottom: '20px', fontSize: '20px', borderBottom: '1px solid #333', paddingBottom: '10px' }}>🏗️ Crear Nuevo Nodo</h2>

            <form onSubmit={handleSubmit}>
                <label style={labelStyle}>ID del Nodo (ej. plaza_norte)</label>
                <input type="text" name="id" required style={inputStyle} onChange={handleInputChange} />

                <label style={labelStyle}>Título para el Menú</label>
                <input type="text" name="titulo" required style={inputStyle} onChange={handleInputChange} />

                <div style={{ display: 'flex', gap: '15px' }}>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>Foto 360 (.webp)</label>
                        <input type="file" accept=".webp" required style={inputStyle} onChange={handleFile360Change} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>Miniatura (400x300)</label>
                        <input type="file" accept=".webp,.jpg" required style={inputStyle} onChange={handleMiniChange} />
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '15px' }}>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>Mapa X (%)</label>
                        <input type="number" name="mapa_x" step="0.1" style={inputStyle} defaultValue={50} onChange={handleInputChange} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label style={labelStyle}>Mapa Y (%)</label>
                        <input type="number" name="mapa_y" step="0.1" style={inputStyle} defaultValue={50} onChange={handleInputChange} />
                    </div>
                </div>

                <button 
                    type="submit" 
                    disabled={cargando}
                    style={{
                        width: '100%', padding: '14px', marginTop: '10px',
                        backgroundColor: cargando ? '#444' : '#fff', 
                        color: '#000', border: 'none', borderRadius: '12px', 
                        fontWeight: 'bold', cursor: cargando ? 'not-allowed' : 'pointer', 
                        fontSize: '15px'
                    }}
                >
                    {cargando ? 'Subiendo archivos...' : 'Guardar Nodo Completo'}
                </button>
            </form>

            {mensaje && (
                <div style={{ marginTop: '20px', textAlign: 'center', fontWeight: '500', color: mensaje.includes('Error') || mensaje.includes('❌') ? '#ff4d4d' : '#4dff4d' }}>
                    {mensaje}
                </div>
            )}
        </div>
    );
}