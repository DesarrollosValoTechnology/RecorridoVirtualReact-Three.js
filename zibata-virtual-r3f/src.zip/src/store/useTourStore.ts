// src/store/useTourStore.ts
import { create } from 'zustand';
import { supabase } from '../supabase/client';

const getInitialNode = () => {
    const params = new URLSearchParams(window.location.search);
    return params.get('nodo') || 'zibata';
};

interface TourState {
    nodoActual: string;
    isTransitioning: boolean;
    fadeActivo: boolean;
    logoVisible: boolean;
    logoTranslucido: boolean;
    mostrarElementos3D: boolean;
    userQuiereRotacion: boolean;
    idiomaActual: 'es' | 'en';
    menuAbierto: boolean;
    panelActivo: 'contacto' | 'compartir' | 'ubicacion' | 'mapa' | null;
    nodos: Record<string, any>;
    cargandoNodos: boolean;
    cargarNodos: () => Promise<void>;
    setNodoActual: (id: string) => void;
    setFadeActivo: (val: boolean) => void;
    setIsTransitioning: (val: boolean) => void;
    setLogoVisible: (val: boolean) => void;
    setLogoTranslucido: (val: boolean) => void;
    setMostrarElementos3D: (val: boolean) => void;
    setUserQuiereRotacion: (val: boolean) => void;
    setMenuAbierto: (val: boolean) => void;
    setPanelActivo: (val: any) => void;
    toggleRotacion: () => void;
    cambiarIdioma: () => void;
    cargarNodo: (id: string) => void;
    tooltipHover: { titulo: string, miniatura: string, x: number, y: number } | null;
    setTooltipHover: (data: any) => void;
    adminPanelActivo: 'nuevoNodo' | 'editorHotspots' | 'editarNodo' | 'editorLabels' | null;
    setAdminPanelActivo: (panel: 'nuevoNodo' | 'editorHotspots' | 'editarNodo' | 'editorLabels' | null) => void;
    actualizarPosicionLabel: (id: string, x: number, y: number, z: number) => Promise<void>;
    actualizarNodoActual: (cambios: any) => Promise<void>;
    actualizarPosicionHotspot: (id: string, x: number, y: number, z: number) => Promise<void>;
    crearNuevoHotspot: () => Promise<void>;
    hotspotSeleccionadoId: string | null;
    setHotspotSeleccionadoId: (id: string | null) => void;
    actualizarPropiedadesHotspot: (id: string, destino: string, tipo: string) => Promise<void>;
    borrarHotspot: (id: string) => Promise<void>;
    labelSeleccionadoId: string | null;
    setLabelSeleccionadoId: (id: string | null) => void;
    crearNuevoLabel: () => Promise<void>;
    actualizarPropiedadesLabel: (id: string, campo: string, valor: any) => Promise<void>;
    borrarLabel: (id: string) => Promise<void>;
    fovActual: number;
    setFovActual: (fov: number) => void;
}

export const useTourStore = create<TourState>((set, get) => ({
    // --- ESTADOS INICIALES ---
    adminPanelActivo: null,
    setAdminPanelActivo: (panel) => set({ adminPanelActivo: panel }),

    nodoActual: getInitialNode(),
    isTransitioning: false,
    fadeActivo: false,
    logoVisible: true,
    logoTranslucido: false,
    mostrarElementos3D: false,
    userQuiereRotacion: true,
    idiomaActual: 'es',
    menuAbierto: false,
    panelActivo: null,
    tooltipHover: null,
    nodos: {},
    cargandoNodos: true,

    // --- CARGA DESDE SUPABASE ---
    cargarNodos: async () => {
        const { data, error } = await supabase
            .from('nodos')
            .select(`
                *,
                hotspots:hotspots!hotspots_nodo_origen_id_fkey(*),
                labels(*)
            `);

        if (error) {
            console.error("Error al cargar Supabase:", error);
            set({ cargandoNodos: false });
            return;
        }

        const diccionarioNodos: Record<string, any> = {};

        data.forEach((nodoDB) => {
            diccionarioNodos[nodoDB.id] = {
                tipo: 'foto',
                // 🗄️ Campos migrados desde nodos.ts → Supabase
                archivo:      nodoDB.foto_url,
                archivoBlur:  nodoDB.archivo_blur_url || nodoDB.foto_url,
                lat:          nodoDB.lat,
                lng:          nodoDB.lng,
                mapaX:        nodoDB.mapa_x,
                mapaY:        nodoDB.mapa_y,
                norteOffset:  nodoDB.norte_offset,
                ui: {
                    titulo:    nodoDB.titulo,
                    categoria: nodoDB.categoria || 'General',       // ← columna nueva
                    miniatura: nodoDB.miniatura_url || nodoDB.foto_url,
                },
                hotspots: nodoDB.hotspots.map((h: any) => ({
                    id:       h.id,
                    destino:  h.nodo_destino_id,
                    tipo:     h.tipo,
                    posicion: { x: h.x, y: h.y, z: h.z },
                })),
                // ✅ CÓDIGO NUEVO (Pon este)
                labels: nodoDB.labels.map((l: any) => ({
                    id:       l.id,
                    texto_es: l.texto_es, // 👈 Extraemos el español
                    texto_en: l.texto_en, // 👈 Extraemos el inglés
                    target:   { x: l.x, y: l.y, z: l.z },
                    offset:   { x: 0, y: l.offset_y || 15, z: 0 },
                })),
            };
        });

        let nodoFinal = get().nodoActual;
        if (!diccionarioNodos[nodoFinal]) nodoFinal = 'zibata';

        set({ nodos: diccionarioNodos, nodoActual: nodoFinal, cargandoNodos: false });
    },

    // --- EDITOR: HOTSPOTS ---
    hotspotSeleccionadoId: null,
    setHotspotSeleccionadoId: (id) => set({ hotspotSeleccionadoId: id }),

    actualizarPosicionHotspot: async (id, x, y, z) => {
        // Optimista local
        const nodosActuales = { ...get().nodos };
        const nodoId = get().nodoActual;
        if (nodosActuales[nodoId]) {
            nodosActuales[nodoId].hotspots = nodosActuales[nodoId].hotspots.map((h: any) =>
                h.id === id ? { ...h, posicion: { x, y, z } } : h
            );
            set({ nodos: nodosActuales });
        }
        // Nube
        const { error } = await supabase.from('hotspots').update({ x, y, z }).eq('id', id);
        if (error) console.error("Error al guardar posición:", error);
    },

    crearNuevoHotspot: async () => {
        const nodoOrigen = get().nodoActual;
        const { error } = await supabase
            .from('hotspots')
            .insert([{ nodo_origen_id: nodoOrigen, nodo_destino_id: nodoOrigen, x: 0, y: 0, z: -50, tipo: 'pasos' }]);
        if (!error) await get().cargarNodos();
    },

    actualizarPropiedadesHotspot: async (id, destino, tipo) => {
        // Optimista local
        const nodosActuales = { ...get().nodos };
        const nodoId = get().nodoActual;
        if (nodosActuales[nodoId]) {
            nodosActuales[nodoId].hotspots = nodosActuales[nodoId].hotspots.map((h: any) =>
                h.id === id ? { ...h, destino, tipo } : h
            );
            set({ nodos: nodosActuales });
        }
        // Nube
        const { error } = await supabase.from('hotspots').update({ nodo_destino_id: destino, tipo }).eq('id', id);
        if (error) console.error("Error al actualizar hotspot:", error);
    },

    borrarHotspot: async (id) => {
        const { error } = await supabase.from('hotspots').delete().eq('id', id);
        if (!error) {
            set({ hotspotSeleccionadoId: null });
            get().cargarNodos();
        }
    },

    // --- EDITOR: NODO ---
    actualizarNodoActual: async (cambios) => {
        const id = get().nodoActual;
        const { error } = await supabase.from('nodos').update(cambios).eq('id', id);

        if (error) {
            console.error("Error al actualizar nodo:", error);
        } else {
            const nodosActuales = { ...get().nodos };
            if (nodosActuales[id]) {
                nodosActuales[id] = {
                    ...nodosActuales[id],
                    mapaX:       cambios.mapa_x       !== undefined ? cambios.mapa_x       : nodosActuales[id].mapaX,
                    mapaY:       cambios.mapa_y       !== undefined ? cambios.mapa_y       : nodosActuales[id].mapaY,
                    norteOffset: cambios.norte_offset !== undefined ? cambios.norte_offset : nodosActuales[id].norteOffset,
                    lat:         cambios.lat          !== undefined ? cambios.lat          : nodosActuales[id].lat,
                    lng:         cambios.lng          !== undefined ? cambios.lng          : nodosActuales[id].lng,
                };
                nodosActuales[id].ui.titulo    = cambios.titulo    || nodosActuales[id].ui.titulo;
                nodosActuales[id].ui.categoria = cambios.categoria || nodosActuales[id].ui.categoria;
                set({ nodos: nodosActuales });
                console.log("✅ Nodo actualizado correctamente");
            }
        }
    },

    // --- NAVEGACIÓN ---
    setNodoActual:        (id)  => set({ nodoActual: id }),
    setFadeActivo:        (val) => set({ fadeActivo: val }),
    setIsTransitioning:   (val) => set({ isTransitioning: val }),
    setLogoVisible:       (val) => set({ logoVisible: val }),
    setLogoTranslucido:   (val) => set({ logoTranslucido: val }),
    setMostrarElementos3D:(val) => set({ mostrarElementos3D: val }),
    setUserQuiereRotacion:(val) => set({ userQuiereRotacion: val }),
    setMenuAbierto:       (val) => set({ menuAbierto: val }),
    // 🚨 ESTE ES EL NUEVO BLOQUE (Asegúrate de que termine con coma al final)
    setPanelActivo: (val) => {
        set({ panelActivo: val });
        // Si cerramos un panel, por pura seguridad borramos cualquier tooltip flotante
        if (val === null) {
            set({ tooltipHover: null });
        }
    },
    toggleRotacion: () => set((s) => ({ userQuiereRotacion: !s.userQuiereRotacion })),
    cambiarIdioma:  () => set((s) => ({ idiomaActual: s.idiomaActual === 'es' ? 'en' : 'es' })),
    setTooltipHover:(val) => set({ tooltipHover: val }),

    cargarNodo: (id) => {
        if (get().isTransitioning || id === get().nodoActual) return;
        const nodosDB = get().nodos;
        const preloadImg = new Image();
        if (nodosDB[id]?.archivo) preloadImg.src = nodosDB[id].archivo;

        const nuevaUrl = new URL(window.location.href);
        nuevaUrl.searchParams.set('nodo', id);
        window.history.pushState({}, '', nuevaUrl);

        set({ isTransitioning: true, fadeActivo: true, menuAbierto: false, panelActivo: null });
        setTimeout(() => set({ nodoActual: id }), 500);
    },
    labelSeleccionadoId: null,

    setLabelSeleccionadoId: (id) => set({ labelSeleccionadoId: id }),

    crearNuevoLabel: async () => {
        const { nodoActual, cargarNodos } = get();
        // Posición inicial frente a la cámara
        const nuevoLabel = {
            nodo_id: nodoActual,
            texto_es: 'Nueva Etiqueta',
            texto_en: 'New Label',
            x: 0, y: 0, z: -5,
            offset_y: 120
        };

        const { error } = await supabase.from('labels').insert([nuevoLabel]);
        if (!error) await cargarNodos();
    },

    actualizarPropiedadesLabel: async (id, campo, valor) => {
        // 1. Actualización Optimista (Local)
        const { nodos, nodoActual } = get();
        const nuevosNodos = { ...nodos };
        const label = nuevosNodos[nodoActual].labels.find((l: any) => l.id === id);
        
        if (label) {
            if (campo === 'offset_y') {
                label.offset = { ...label.offset, y: valor };
            } else {
                label[campo] = valor;
            }
        }
        set({ nodos: nuevosNodos });

        // 2. Actualización en Nube
        const columnMap: any = { 'offset_y': 'offset_y', 'texto_es': 'texto_es', 'texto_en': 'texto_en' };
        await supabase.from('labels').update({ [columnMap[campo] || campo]: valor }).eq('id', id);
    },

    borrarLabel: async (id) => {
        const { cargarNodos } = get();
        const { error } = await supabase.from('labels').delete().eq('id', id);
        if (!error) {
            set({ labelSeleccionadoId: null });
            await cargarNodos();
        }
    },
    // --- AGREGA ESTA FUNCIÓN EN EL CUERPO DEL STORE ---
    actualizarPosicionLabel: async (id, x, y, z) => {
        const { nodos, nodoActual } = get();
        const nuevosNodos = { ...nodos };
        const label = nuevosNodos[nodoActual].labels.find((l: any) => l.id === id);

        if (label) {
            // Actualización optimista local 
            // (Usamos .target porque así lo definiste en tu función cargarNodos)
            label.target = { x, y, z };
            set({ nodos: nuevosNodos });
        }

        // Actualización en Supabase
        const { error } = await supabase.from('labels').update({ x, y, z }).eq('id', id);
        if (error) console.error("Error al guardar posición del label:", error);
    },
    fovActual: 60, // Zoom inicial
    setFovActual: (fov) => set({ fovActual: fov }),
}));